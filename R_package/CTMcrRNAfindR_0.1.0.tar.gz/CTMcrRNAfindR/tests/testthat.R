# This file is part of the standard setup for testthat.
# It is recommended that you do not modify it.
#
# Where should you do additional test configuration?
# Learn more about the roles of various files in:
# * https://r-pkgs.org/testing-design.html#sec-tests-files-overview
# * https://testthat.r-lib.org/articles/special-files.html

library(testthat)
library(CTMcrRNAfindR)

#test_check("CTMcrRNAfindR")

CTM_crRNAfindR(search_regions = "inst/extdata/Feature_collection_testing.xlsx",
         blastdb_location = file.path("C:/Users", Sys.info()[["effective_user"]], "Documents/R_Dir/NCBI_dbs/mm39_own/mm39_db"),
         main_output_folder= file.path("C:/Users", Sys.info()[["effective_user"]],"Desktop", "CTM_crRNA_out"),
         folder_CRISPOR_scores = file.path("C:/Users", Sys.info()[["effective_user"]],"Desktop", "CTM_crRNA_out", "CRISPOR_scores"),
         max_OH_score = 1,
         skip_after_blast =T)
