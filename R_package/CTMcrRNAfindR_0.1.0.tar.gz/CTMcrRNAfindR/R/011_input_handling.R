#' Create crRNA search window
#'  @title filter_input
#' @description
#' A short description...
#'
#' @param filepath location of excel or csv file with information
#' @param columnames vector with columns to include, default_colnames = c("name", "chr", "start", "end", "strand", "window")
#' @param merged_name_cols vector with columns to merge to a single "name"column (default = c("name"))
#' @param filtercols columns to use as filters (vector, index relates to filters)
#' @param filters filter criteria to apply (vector, indes consistent with filter_cols)
#'
#' @importFrom tidyr unite
#' @importFrom tools file_ext
#' @importFrom magrittr %>%
#' @importFrom dplyr filter
#' @importFrom dplyr select
#' @importFrom dplyr all_of
#' @importFrom dplyr rename
#' @importFrom readxl read_xlsx
#'
#'
filter_input = function(filepath, columnames = c(), merged_name_cols = c("name"), filtercols=c(), filters=c()){
  if (file.exists(filepath)) {
    ext =tools::file_ext(filepath)
    if(ext == "xlsx"){
      input = read_xlsx(filepath)
    }
    if(ext == "csv"){
      input=read.csv(filepath)
    }
  }else{
    print("Invalid input filepath")
    return()
  }
  input = input %>%
    unite("full_name", all_of(merged_name_cols), sep = "_", remove = F)
  default_colnames = c("name", "chr", "start", "end", "strand", "window")
  if (length(columnames)!=0) {
    namesets <- setNames(columnames,default_colnames)
    input = rename(input, any_of(namesets))
  }
  input$merged_filtercols=do.call(paste, c(input[filtercols], sep = "_"))
  input$merged_criteria = do.call(paste, c(list(filters), collapse = "_"))
  input = input %>% filter(merged_filtercols==merged_criteria)
  input = input %>% select(-c(merged_filtercols, merged_criteria))
  return(input)
}

