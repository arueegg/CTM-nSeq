

#' @title CTMSeq crRNAfindR Main
#' @description
#' Main function to execute CTM-Seq's crRNAfinder
#'
#' @param search_regions path to an excel file to define input parameters for multiple target regions to be used in a single experiment, ideally contains the standard colnames (c("Assoc_locus", "Chr", "start", "end", "strand", "window", "feature"))
#' @param blastdb_location location of blast database to use (created by rBLAST)
#' @param main_output_folder folder to save any output data in
#' @param folder_CRISPOR_scores a folder containing xlsx files with DeepCpf1 scores exported from CRISPOR
#' @param get_crRNAs_only should only the first part of the script be run to retrieve cRNAs and Sequences for ROIs (T/F, default =F)

#' @param Cas.type type of Cas12a enzyme used (one of "As", "Lb", "Fn", default = "As") will be appended to crRNA names
#' @param PAM PAM (may contain V or N as ambiguity characters)
#' @param protospacer_length length of protospacer (default 20), will be appended to crRNA names
#' @param OH_start position after PAM where overhang starts (default = 19)
#' @param OH_end position after PAM where overhang ends (default = 23)
#' @param pGC min. GC content of overhang (default = 0.6)

#' @param sequence_extension bp by which the ROI should be extended (default = 6000, should be bigger than search_window, only for sequences, not relevant for search window)
#' @param genome a BSgenome object generated through getBSgenome() (eg. "BSgenome.Mmusculus.UCSC.mm39")

#' @param input_cols  vector with columns to include, must contain an equivalent (by position) of the default column names: c("name", "chr", "start", "end", "strand", "window"), strand should be given as "+"/"-"
#' @param name_cols vector with columns to merge to a single "name"column (default = c("name"))
#' @param filter_cols columns to use as filters (vector, index relates to filters)
#' @param filter_value filter criteria to apply (vector, indes consistent with filter_cols)
#'
#' @param search_window search window to apply (if set to False, set to default = 2000 bases), only used if no window column is provided in input file
#' @param search_buffer buffer (in bases) to add between ROI and search window (default = 100)
#' @param save_all_ROI_fasta should a fasta file with the extended ROI sequences be saved
#' @param save_all_crRNA_excel should an excel file with all crRNAs found be saved
#'
#'
#' @param filter_by_scores should crRNAs be filtered by CRISPOR and RNAfold scores (T/F). For doing so, it is recommended to first run the script once with the "get_crRNAs_only" option which allows to retrieve the sequences of target regions, use the sequences to run CRISPOR (https://crispor.gi.ucsc.edu/crispor.py). Run CRISPOR without Genome to allow for longer input sequences, then download "Guides" as Excel table and save in a folder ("folder_CRISPOR_scores").
#' @param min_deepcpf1_score minimum deepcpf1 score (1-100)
#' @param RNAfold.path path for Vienna RNAfold (e.g. "C/.../AppData/Local/Programs/ViennaRNA/RNAfold.exe")
#' @param min_fold_score minimum RNAfold score (1-100)
#'
#' @param save_blast_results should results from blast be saved (T/F, default = T)
#' @param skip_after_blast should steps before and including blast be skipped (usefull if error in overhang comparison occured (T/F, default = F
#'
#' @param max_OH_score maximum number of matches between fw OH and complement of rv OH
#' @param OH_gapOpen parameters passed to pairwiseAlignment for matching overhangs
#' @param OH_gapExtend parameters passed to pairwiseAlignment for matching overhangs
#' @param optimize_sets_by functions to be used to find best sets (vector including elements of c("max_median", "min_variance", "combine_DeepCpf1_Fold"))
#' @param optimize_scores scores (either "DeepCpf1_score", "structure_score", or avector with both, that should be opitimized in optimize_sets_by
#'
#' @export CTM_crRNAfindR
#'
#' @importFrom writexl write_xlsx





CTM_crRNAfindR = function(
    search_regions,
    blastdb_location,
    main_output_folder,
    folder_CRISPOR_scores,
    get_crRNAs_only = F,
    Cas.type = "As",
    PAM = "TTTV",
    protospacer_length = 20,
    OH_start  =18,
    OH_end = 22,
    pGC =0.5,
    sequence_extension =3000,
    genome = BSgenome::getBSgenome("BSgenome.Mmusculus.UCSC.mm39"),
    #to get crRNAs
    input_cols  = c("Assoc_locus", "Chr", "start", "end", "strand", "window"),
    name_cols = c("Assoc_locus", "feature"),
    filter_cols =c("feature"),
    filter_value =c("ROI"),
    search_window=F,
    search_buffer=100,
    save_all_ROI_fasta = T,
    save_all_crRNA_excel = T,

    #filtering using CRISPOR & RNAfold
    filter_by_scores = T,
    min_deepcpf1_score = 20,
    min_fold_score = 20,
    RNAfold.path = ifelse(Sys.info()["sysname"][[1]] == "Windows",
                          file.path("C:/Users", Sys.info()[["effective_user"]], "AppData/Local/Programs/ViennaRNA/RNAfold.exe"),
                          "RNAfold"),
    #save blast results
    save_blast_results = T,
    skip_after_blast = F,

    #OH scoring and set selection
    max_OH_score = 1,
    OH_gapOpen = 10,
    OH_gapExtend = 4,
    optimize_sets_by = c("max_median", "min_variance", "combine_DeepCpf1_Fold"),
    optimize_scores = c("DeepCpf1_score", "structure_score")


    ) {
  dir.create(file.path(main_output_folder), showWarnings = FALSE)
  dir.create(file.path(folder_CRISPOR_scores), showWarnings = FALSE)
  dir.create(file.path(file.path(main_output_folder, "All_crRNAs")), showWarnings = FALSE)
  dir.create(file.path(main_output_folder, "Sets_CTMnSeq"), showWarnings = FALSE)
  if (skip_after_blast == F) {
    all_crRNAs = get_crRNAs(infile = search_regions,
                            columnames  = input_cols,
                            merged_name_cols = name_cols,
                            filtercols =filter_cols,
                            filters =filter_value,
                            genome = genome,
                            sequence_extension =sequence_extension,
                            search_window=search_window,
                            search_buffer=search_buffer,
                            save_fasta = save_all_ROI_fasta,
                            save_excel = save_all_crRNA_excel,
                            sequences_out =file.path(main_output_folder, "All_crRNAs") ,
                            Cas.type = Cas.type,
                            PAM = PAM,
                            protospacer_length = protospacer_length,
                            OH_start  =OH_start,
                            OH_end = OH_end,
                            pGC =pGC )
    if (get_crRNAs_only) {
      return(all_crRNAs)
    }
    if (filter_by_scores){
      print("***** INCLUDING CRIPSOR & RNA FOLD SCORES *****")
      include_scores= include_scores(folder_CRISPOR_scores =folder_CRISPOR_scores,
                                     dataframe = all_crRNAs,
                                     protospacer_col ="protospacer",
                                     min_deepcpf1_score =min_deepcpf1_score,
                                     RNAfold.path = RNAfold.path,
                                     crRNA_loop_species = Cas.type,
                                     min_fold_score =min_fold_score)
      df_for_blast = include_scores
    } else{
      add_cols = c("DeepCpf1_score","seq.FullcrRNA","sec_structure","MFE","structure_score")
      df_for_blast = all_crRNAs
      df_for_blast[, add_cols] = NA
    }
    print("***** USING BLAST TO TEST SPECIFICITY *****")
    blast_them_all = blastnfilter_crRNAs(df_for_blast,
                                         spacer_col = "protospacer",
                                         name_col = "name.crRNA",
                                         PAM = PAM,
                                         pos = protospacer_length+length(PAM),
                                         blastdb_location = blastdb_location,
                                         redirect_blastloc = ifelse(Sys.info()["sysname"][[1]] == "Windows",
                                                                    T, F))
    if (save_blast_results) {
      writexl::write_xlsx(blast_them_all, path = file.path(main_output_folder, "All_crRNAs", "blast_results_all.xlsx"))
      full_summary=combine_data(include_scores = df_for_blast,
                                all_crRNAs = all_crRNAs,
                                blast_summary = blast_them_all[[1]],
                                ONT_NA_OH = "ATTGCT",
                                Linker_core = "GGGCGAACAATGCAGG")
      writexl::write_xlsx(blast_them_all, path = file.path(main_output_folder, "All_crRNAs", "full_summary.xlsx"))
    }
  }else{
    full_summary = readxl::read_xlsx(file.path(main_output_folder, "All_crRNAs", "full_summary.xlsx"), sheet = 1)
  }


  print("***** FINDING SETS WITH COMPATIBLE OVERHANGS *****")
  get_OH_sets(crRNA_dataframe = full_summary,
              out_folder= file.path(main_output_folder, "Sets_CTMnSeq"),
              crRNA_name_col = "name.crRNA",
              overhangs_col = "OH",
              strand_col = "strand",
              group_name_sep = "_.*",
              max_score = max_OH_score,
              gapOpen = OH_gapOpen,
              gapExtend = OH_gapExtend,
              optimize_by = optimize_sets_by,
              scores = optimize_scores)
}
