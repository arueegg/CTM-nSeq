#' Create crRNA search window
#' @title Create crRNA search window df
#'
#' @param folder_CRISPOR_scores a folder containing xlsx files with DeepCpf1 scores exported from CRISPOR
#' @param dataframe dataframe with guides to add the scores to. must contain a column with the protospacer sequence (identical to the one found in the CRISPOR exports.)
#' @param protospacer_col column name found in dataframe containing protospacer sequences
#' @param min_deepcpf1_score minimum deepcpf1 score (1-100)
#' @param RNAfold.path path for Vienna RNAfold (e.g. "C/.../AppData/Local/Programs/ViennaRNA/RNAfold.exe")
#' @param crRNA_loop_species crRNA stem-loop sequence or type of Cas12a protein used. currently supported are "As", "Lb" or "Fn"
#' @param min_fold_score minimum RNAfold score (1-100)
#'
#' @importFrom dplyr select
#' @importFrom magrittr %>%
#' @importFrom readxl read_excel
#' @importFrom data.table rbindlist
#'
include_scores= function(folder_CRISPOR_scores,
                         dataframe,
                         protospacer_col,
                         min_deepcpf1_score,
                         RNAfold.path = "RNAfold",
                         crRNA_loop_species = "As",
                         min_fold_score){
  file_list = list.files(path = folder_CRISPOR_scores, pattern = "*.xls", full.names = TRUE)
  CRISPOR_data =  data.table::rbindlist(lapply(file_list, readxl::read_excel, skip = 7), use.names = FALSE)
  CRISPOR_min = data.frame(matrix(nrow = nrow(CRISPOR_data), ncol = 0))
  CRISPOR_min$protospacer = substr(CRISPOR_data$targetSeq, 5, nchar(CRISPOR_data$targetSeq)-1)
  CRISPOR_min$DeepCpf1_score = as.numeric(CRISPOR_data$`DeepCpf1-Score`)
  dataframe$ps = dataframe[[protospacer_col]]
  CRISPOR_min = CRISPOR_min %>%
    filter(protospacer %in% dataframe$ps) %>%
    filter(DeepCpf1_score>=min_deepcpf1_score)
  combined_df_w_CRISPOR = merge(CRISPOR_min, dataframe, by.x ="protospacer", by.y =  "ps")
  combined_df_w_CRISPOR <- combined_df_w_CRISPOR %>% select(-any_of("protospacer.y"))
  combined_df_CFo = get_rnafold_scores(df=combined_df_w_CRISPOR,
                                       protospacer_col=protospacer_col,
                                       crRNA_loop_species  = crRNA_loop_species,
                                       RNAfold.path = RNAfold.path)%>%
    filter(structure_score>=min_fold_score)
  return(combined_df_CFo)
}

