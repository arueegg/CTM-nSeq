#' @title ROIs to wide
#' @description transform wide format of imported dataframe with added search windows into a long dataframe
#'
#'
#' @param ROIs_df_windows dataframe with genome coordinates (only works on dataframes generated
#' through filter_input & define_search_windows)
#' @importFrom tidyr unite pivot_longer
#' @importFrom magrittr %>%
#'
ROIs_to_crRNA_df = function(ROIs_df_windows){
  ROIs_df_windows =ROIs_df_windows %>% unite("start.roi", all_of(c("start")), sep = "_", remove = T)
  ROIs_df_windows =ROIs_df_windows %>% unite("end.roi", all_of(c("end")), sep = "_", remove = T)
  ROIs_df_windows =ROIs_df_windows %>% unite("strand.roi", all_of(c("strand")), sep = "_", remove = T)

  crRNA_df_long <- ROIs_df_windows %>%
    pivot_longer(
      cols = !c(name,chr, start.roi, end.roi, strand.roi,seq.feature,seq.ROI, additional, nameprefix.crRNA, window),
      names_to = c(".value", "direction.crRNA"),
      names_pattern = "(.*)\\.(.*)",
      values_to = c("start", "end","strand"),
      values_drop_na = F
    )
  crRNA_df_long$name.crRNA = paste(crRNA_df_long$nameprefix.crRNA,
                                   crRNA_df_long$direction.crRNA,
                                   sep = ".")
  return(crRNA_df_long)
}
