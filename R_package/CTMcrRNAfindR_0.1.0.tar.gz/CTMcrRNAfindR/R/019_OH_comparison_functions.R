#' @title Get best sets of crRNAs
#'
#' @description get the best combinations of crRNA sets across all groups
#'
#' @param crRNA_dataframe dataframe containing combined information (scores, OHs, sequences)
#' @param out_folder path of output folder (will be generated if not exists)
#' @param crRNA_name_col naming column for crRNAs found in crRNA_dataframe
#' @param overhangs_col overhang column for crRNAs found in crRNA_dataframe
#' @param strand_col strand (+/-) column for crRNAs found in crRNA_dataframe
#' @param group_name_sep group_name_sep regex string to separate groups from rest in row and columnames
#' @param max_score maximum number of matches between fw OH and complement of rv OH
#' @param gapOpen parameters passed to pairwiseAlignment
#' @param gapExtend parameters passed to pairwiseAlignment
#' @param optimize_by functions to be used to find best sets (one of "max_median", "min_variance", "combine_DeepCpf1_Fold")
#' @param scores scores (found in crRNA dataframe) that should be opitimized
#'
#' @export get_OH_sets
#' @importFrom magrittr %>%
#' @importFrom dplyr filter select
#' @importFrom writexl write_xlsx
#'
get_OH_sets = function(crRNA_dataframe,
                       out_folder,
                       crRNA_name_col = "name.crRNA",
                       overhangs_col = "OH",
                       strand_col = "strand",
                       group_name_sep ="_.*",
                       max_score =1,
                       gapOpen = 10,
                       gapExtend = 4,
                       optimize_by = c("max_median", "min_variance", "combine_DeepCpf1_Fold"),
                       scores = c("DeepCpf1_score", "structure_score")){
  if (!dir.exists(out_folder)) {
    dir.create(out_folder, recursive = TRUE)
  }
  OH_scores = Overhang_comparison(crRNA_dataframe = crRNA_dataframe,
                                  crRNA_name_col = crRNA_name_col,
                                  overhangs_col = overhangs_col,
                                  strand_col = strand_col,
                                  gapOpen = gapOpen,
                                  gapExtend = gapExtend)

  OH_group_sets = create_OH_comp_matrix(OH_scores,
                                        rnames = rownames(OH_scores),
                                        cnames = colnames(OH_scores),
                                        group_name_sep =group_name_sep,
                                        max_score =max_score)
  if (is.null(OH_group_sets)) {
    cat(crayon::red$bold(sprintf('\n\nSTOPPED execution NO valid overhang combinations\n\n')))
    return()
  }
  if (all(!is.na(OH_group_sets[[1]]))) {
    for (score in scores) {
      for (funct in optimize_by) {
        output_path = file.path(out_folder, funct)
        get_best_OH_sets(OH_score_named_results = OH_group_sets$named_results,
                         combined_data_df = crRNA_dataframe,
                         output_path,
                         apply_fun = funct,
                         parameter = score)
      }
    }
  }
}

#' @title OH compatibility calculation wrapper function
#'
#' @param OH_score_named_results name (not index) output of create_OH_comp_matrix create_OH_comp_matrix$named_results
#' @param combined_data_df dataframe with all information onf crRNAs (including score columns)
#' @param output_path path of output folder for xlsx files with sets and csv for snapgene primer import (will be generated if not exists)
#' @param apply_fun function to score parameter with (one of "max_median", "min_variance", "combine_DeepCpf1_Fold")
#' @param parameter column of combined_data_df to get best values from
#'
#' @importFrom magrittr %>%
#' @importFrom dplyr filter select
#' @importFrom writexl write_xlsx
#' @importFrom readr write_tsv

get_best_OH_sets = function(OH_score_named_results,
                         combined_data_df,
                         output_path,
                         apply_fun = "max_median", #or min_variance
                         parameter = "DeepCpf1_score"){
  df = as.data.frame(OH_score_named_results)
  outdir = output_path#file.path(output_path, apply_fun)
  if (!dir.exists(outdir)) {
    dir.create(outdir, recursive = TRUE)
  }

  all_sets =list()
  for (row in 1:nrow(df)) {
    find = as.character(df[row,])
    select_cols = c("name.crRNA", "name", "direction.crRNA", "DeepCpf1_score", "structure_score", "sec_structure" ,
                    "protospacer", "OH", "Linker_rv")
    existing_cols = select_cols[select_cols %in% colnames(combined_data_df)]
    group_df = combined_data_df[combined_data_df[["name.crRNA"]] %in% find,]
    group_df = group_df %>% dplyr::select(dplyr::all_of(existing_cols))
    all_sets[[row]] = group_df
  }

  if (apply_fun == "max_median") {
    best_scores <- sapply(all_sets, function(df) median(df[[parameter]], na.rm = TRUE))
    top_indices <- order(best_scores, decreasing = TRUE)[1:3]
  }else{
    if (apply_fun == "min_variance") {
      best_scores <- sapply(all_sets, function(df) var(df[[parameter]], na.rm = TRUE))
      top_indices <- order(best_scores, decreasing = FALSE)[1:3]
    }else{
      if(apply_fun == "combine_DeepCpf1_Fold"){
        combi_score <- sapply(all_sets, function(df) median(sum(df$DeepCpf1_score, df$structure_score), na.rm = TRUE))
        top_indices <- order(combi_score, decreasing = TRUE)[1:3]
      }else{
        print("We could not determine the function to use. All sets will be retrieved")
        top_indices = 1:length(all_sets)
      }
    }
  }

  for (i in top_indices) {
    writexl::write_xlsx(all_sets[i], file.path(outdir, paste0(parameter, "_", apply_fun, sprintf("%03d", i),".xlsx")))
    # export_snapgene = data.frame(matrix(nrow = nrow(all_sets[[i]]), ncol = 0))
    # export_snapgene$Name = all_sets[[i]]$name.crRNA
    # export_snapgene$Sequence = paste0(all_sets[[i]]$PAM,all_sets[[i]]$protospacer)
    # export_snapgene$Notes = paste(all_sets[[i]]$OH, all_sets[[i]]$DeepCpf1_score, all_sets[[i]]$structure_score)
    # write_tsv(export_snapgene, file.path(outdir, paste0(parameter, "_", apply_fun, sprintf("%03d", i), "_export_snapgene.txt")))
  }
}

#' @title OH compatibility calculation wrapper function
#'
#' @param df dataframe to generate matrix with overhang scores
#' @param rnames row names found in df
#' @param cnames column names found in df
#' @param group_name_sep separater in rnames and cnames to split names into group and element name (group name must be preceding element name)
#' @param max_score maximum acceptable match score for OHs (1 = 1 base of OH can pair)
#' @param reshape_to01 boolean - should match score matrix be reshaped to 0 (higher score than acceptable) and 1 (score acceptable)

create_OH_comp_matrix = function(df, rnames, cnames,group_name_sep, max_score, reshape_to01= F){
  input = reorganize_mat(dataframe=df,
                         rnames = rnames,
                         cnames=cnames,
                         group_name_sep = group_name_sep,
                         max_score = max_score,
                         reshape_to01= F)
  good_sets = extract_pairs(matrix = input[[1]],
                                            group_sizes_rows = input[[2]],
                                            group_sizes_cols = input[[3]],
                                            target_value = input[[4]])

  return(good_sets)
}




