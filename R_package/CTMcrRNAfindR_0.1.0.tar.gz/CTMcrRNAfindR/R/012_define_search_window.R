#' Create crRNA search window
#' @title Create crRNA search window df
#'
#' @param dataframe dataframe containing ROI information
#' @param name_col column in dataframe to use as name
#' @param chr_col column in dataframe with end of region position
#' @param start_col column in dataframe with start of region position
#' @param end_col column in dataframe with end of region position
#' @param strand_col column in dataframe with strand (+/-)
#' @param window search window to apply (default = 2000), instead of a single
#' value a vector in length of nrow dataframe can be supplied
#' @param buffer buffer to add between ROI and search window (default = 100)
#' @param Cas.type type of Cas12a enzyme used (default "As") will be used in names of crRNAs
#' @param protospacer_length length of protospacer (default 20), will be used in names of crRNAs
#'
#' @importFrom magrittr %>%

define_search_windows = function(dataframe,
                                 name_col="name",
                                 chr_col = "chr",
                                 start_col = "start",
                                 end_col = "end",
                                 strand_col ="strand",
                                 window=2000,
                                 buffer=100,
                                 Cas.type = "As",
                                 protospacer_length = 20){
  default_colnames = c("name", "chr", "start", "end", "strand")
  ROI_df = data.frame(matrix(nrow=nrow(dataframe),ncol=0))
  ROI_df$name = dataframe[[name_col]]
  ROI_df$chr = dataframe[[chr_col]]
  ROI_df$start = dataframe[[start_col]]
  ROI_df$end = dataframe[[end_col]]
  ROI_df$strand = dataframe[[strand_col]]
  remaining_cols = colnames(dataframe)[!colnames(dataframe) %in% default_colnames]
  ROI_df$additional = paste(dataframe[remaining_cols], collapse = "/t")
  ROI_df$window = window
  ROI_df$start.fw = ROI_df$start-buffer-ROI_df$window
  ROI_df$end.fw= ROI_df$start-buffer
  ROI_df$start.rv = ROI_df$end+buffer
  ROI_df$end.rv= ROI_df$end+buffer+ROI_df$window

  ROI_df$strand.fw = "+"
  ROI_df$strand.rv = "-"
  ROI_df$nameprefix.crRNA = paste(ROI_df$name,
                                           rep(paste0(Cas.type, protospacer_length), length(ROI_df$name)),
                                           sep = "_")
  return(ROI_df)
}
