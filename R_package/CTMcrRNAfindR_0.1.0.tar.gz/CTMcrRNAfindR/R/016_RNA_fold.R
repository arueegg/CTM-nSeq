#' @title Get scores from Vienna RNA folds
#' @param df dataframe with column containing protospacer sequences
#' @param RNAfold.path path for Vienna RNAfold (e.g. "C/.../AppData/Local/Programs/ViennaRNA/RNAfold.exe")
#' @param protospacer_col column name found in dataframe containing protospacer sequences
#' @param crRNA_loop_species crRNA stem-loop sequence or type of Cas12a protein used. currently supported are "As", "Lb" or "Fn"
#' "As" = "TAATTTCTACTCTTGTAGAT"
#' "Lb" = "TAATTTCTACTAGTAGTAGA"
#' "Fn" = "TAATTTCTACTGTTGTAGAT"
#'
#' @importFrom LncFinder run_RNAfold
#' @importFrom magrittr %>%
#'
#' @export get_rnafold_scores

get_rnafold_scores = function(df,
                              RNAfold.path,
                              protospacer_col="protospacer",
                              crRNA_loop_species = "As"
                              ){
  if (crRNA_loop_species %in% c("As", "Lb", "Fn")) {
    lookup = data.frame(seq = c("TAATTTCTACTCTTGTAGAT", "TAATTTCTACTAGTAGTAGA", "TAATTTCTACTGTTGTAGAT"), species = c("As", "Lb", "Fn"))
    loop_seq = (lookup %>% filter(species == crRNA_loop_species))$seq
  }  else{
    print(paste0("no loop for ", crRNA_loop_species, "Cas12a found, using ",crRNA_loop_species))
    loop_seq=crRNA_loop_species
  }
  df_temp = df
  df_temp$ps_col = df_temp[[protospacer_col]]
  df_temp$seq.FullcrRNA = paste0(loop_seq, df_temp$ps_col)
  my_seq <- seqinr::as.SeqFastadna(df_temp$seq.FullcrRNA)

  RNAfold_results <- LncFinder::run_RNAfold(my_seq, RNAfold.path = RNAfold.path, parallel.cores = 6)

  fold_patterns = data.frame(matrix(nrow = ncol(RNAfold_results), ncol =0))
  fold_patterns$seq.FullcrRNA = colnames(RNAfold_results)
  fold_patterns$sec_structure = unlist(RNAfold_results[2,])
  fold_patterns$MFE = as.numeric(unlist(RNAfold_results[3,]))
  fold_patterns$structure_score = fold_patterns$MFE*-1*ifelse(fold_patterns$sec_structure ==
                                                                ".....(((((....))))).....................", 10,
                                                              ifelse(startsWith(fold_patterns$sec_structure, ".....(((((....)))))."), 3, 1))
  fold_patterns$structure_score = round(fold_patterns$structure_score/max(fold_patterns$structure_score)*100,0)
  df_temp = merge(df_temp, fold_patterns, by = "seq.FullcrRNA")
  df_temp = df_temp %>% select(-any_of(colnames(df)))
  df_temp = merge(df, df_temp, by.x = protospacer_col, by.y = "ps_col")
  return(df_temp)
}





