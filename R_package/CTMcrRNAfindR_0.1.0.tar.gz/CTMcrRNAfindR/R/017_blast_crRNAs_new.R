###### Blast  crRNA ######
#' @title Blast  crRNAs
#' @description
#' Uses rBLAst to blast protospacer sequences against an NCBI blast database
#' Blast function adapted for finding off targets of crRNAs.
#' Input is an individual protospacer sequence (string)
#'
#' @param protospacer protospacer sequence (string)
#' @param PAM Potential (not actual) PAM sequence (string), may contain V or N characters, may also be a vector of possible PAMs
#' @param pos Number of nucleotides after PAM to perform blast with (1:pos) (default = 24)
#' @param blastdb Blast database to use (created by rBLAST)
#'
#' @import rBLAST
#' @import Biostrings
#'
#' @export blast_crRNA
#'
blast_crRNA =function(protospacer, PAM = "TTTV", pos = 24, blastdb = make_blast_db()){
  # Generate minimal spacer to allow using only a fraction (1:pos)
  # of the spacer sequence for finding off targets
  mini_spacer = substr(protospacer,1,pos)
  # Create a sequence with PAM and protospacer for each possible PAM variant.
  all_seqs = c()
  if (grepl("V", PAM)) {
    for (variant in c("A","C","G")) {
      PAMvar = gsub("V", variant, PAM)
      all_seqs = c(all_seqs, paste0(PAMvar, mini_spacer))
    }}else{
      if (grepl("N", PAM)) {
        for (variant in c("A","C","G", "T")) {
          PAMvar = gsub("N", variant, PAM)
          all_seqs = c(all_seqs, paste0(PAMvar, mini_spacer))
        }}else{
          all_seqs = c(all_seqs, paste0(PAM, mini_spacer))
        }
    }
  # Create a Biostrings object from vector with sequences to blast
  full_seq = DNAStringSet(all_seqs)

  hits = tryCatch({
    predict(blastdb, full_seq, BLAST_args = "-task blastn-short -num_threads 8 -perc_identity 75 -dust no -soft_masking false -reward 2 -penalty -3 -gapopen 0 -gapextend 4 -evalue 1 -word_size 6")
  }, error = function(e) {
    message(sprintf("Row %s failed: %s", protospacer, e$message))

    # if blast fails, a dataframe row with NA
    as.data.frame(matrix(NA, nrow = 1, ncol = 12))
  })
  return(hits)
}


######Find off-targets of crRNAs######
#' @title Find off-targets of crRNAs
#' @description
#' find off target locations for crRNAs
#' returns a list with:
#' 1) merged summarized df with number of off-targets
#' 2) merged df with off-targets and input df (blast result columns start with "bl.")
#' 3) all off_targets for spacer_col in input df
#' 4) input df
#'
#' @param crRNA_df dataframe with crRNA data, contains at least 1 column for protospacer sequence and 1 column for crRNA name
#' @param spacer_col = columname of column in crRNA_df containing protospacer sequences
#' @param name_col = columname of column in crRNA_df containing crRNA name, must be unique
#' @param PAM potential (can contain ambiguity characters) PAM sequence (string)
#' @param pos number of nucleotides after PAM to consider (default = 24)
#' @param blastdb_location location of blast database to use (created by rBLAST)
#' @param blast_location path for NCBI blast+ (needed under Windows)
#' @param redirect_blastloc Boolean to set path for NCBI blast+ (needed under Windows)
#'
#' @import rBLAST
#' @import Biostrings
#' @import IRanges
#' @import S4Vectors
#' @import future.apply
#' @import pbapply
#' @importFrom dplyr summarize select filter group_by n
#' @importFrom magrittr %>%

blastnfilter_crRNAs = function(crRNA_df,
                               blastdb_location,
                               spacer_col = "protospacer",
                               name_col = "name.crRNA",
                               PAM = "TTTV",
                               pos = 24,
                               blast_location = "C:/Program Files/NCBI/blast-2.17.0+/bin/",
                               redirect_blastloc = F){


  #colnames for blast resuls
  blast_cols = c("qseqid","sseqid","pident","length","mismatch","gapopen","qstart","qend","sstart","send","evalue","bitscore")
  temp_crRNA_df = crRNA_df
  temp_crRNA_df$protospacer = temp_crRNA_df[[spacer_col]]
  temp_crRNA_df$name.crRNA = temp_crRNA_df[[name_col]]
  temp_crRNA_df = temp_crRNA_df[!duplicated(temp_crRNA_df$protospacer), ]

  #perform parallel blast search to avoid too long wait times
  blastdb=make_blast_db(db_location =blastdb_location,
                        blast_location = blast_location,
                        set_blast_location = T,
                        get_blast_location = F)
  future::plan(future::multisession)

  pboptions(type = "timer", char = "=")

  blast_results <- pbapply::pblapply(
    X = seq_len(nrow(temp_crRNA_df)),
    FUN = function(idx) {
      if (redirect_blastloc) {
        make_blast_db(db_location =blastdb_location,
                      blast_location = blast_location,
                      set_blast_location = T,
                      get_blast_location = T)
      }
      current_row <- temp_crRNA_df[idx, , drop = FALSE]

      parallel_blast(current_row, idx, PAM, pos, blastdb)
    },
    cl = "future",
    future.packages = "CTMcrRNAfindR",
    future.seed = TRUE,
    future.globals = list(
      temp_crRNA_df = temp_crRNA_df,
      PAM = PAM,
      pos = pos,
      blastdb = blastdb
    )
  )
  names(blast_results) = temp_crRNA_df$name.crRNA

  # Combine
  final_table <- data.table::rbindlist(blast_results, fill = TRUE, use.names = TRUE, idcol ="name.crRNA")
  #remove NA colums
  final_table <- final_table %>% select(where(~ !all(is.na(.))))

  #merge summary list
  merged_df  = merge(crRNA_df, final_table, by = paste0 (name_col), all.x = F, all.y = T)

  too_many_matches = merged_df %>%
    filter(pident ==100)%>%
    filter(length ==24)%>%
    group_by(across(all_of(colnames(crRNA_df)))) %>%
    summarize(excellent_matches= n())%>%
    filter(excellent_matches>1)

  summary = merged_df %>%
    filter(!(name.crRNA %in% too_many_matches$name.crRNA))%>%
    group_by(across(all_of(colnames(crRNA_df)))) %>%
    summarize(total_offtargets= n()-1,
              offt_0mm = sum(mismatch == 0, na.rm = TRUE) - 1,
              offt_1mm = sum(mismatch == 1, na.rm = TRUE))%>%
    filter(offt_0mm<1)

  output_list = list()
  output_list[["merged_summary"]] = summary
  output_list[["off_targets"]] =final_table
  output_list[["merged_unfiltered"]] =merged_df
  output_list[["input"]] =crRNA_df
  return(output_list)
}

###### Parallelize off target detection for crRNAs######
#' Loop
#' @description helper to paralellize blasting
#' @param named_row inherited from blastnfilter_crRNAs()
#' @param idx index of row in named_row
#' @param PAM inherited from blastnfilter_crRNAs()
#' @param pos inherited from blastnfilter_crRNAs()
#' @param blastdb inherited from blastnfilter_crRNAs()
#' @import future.apply
#' @export parallel_blast
#'
#'
parallel_blast <- function(named_row,idx, PAM, pos, blastdb) {
  hits = list()
  tryCatch({
    hits[[idx]] <-  blast_crRNA(named_row$protospacer, PAM = PAM, pos = pos, blastdb = blastdb)

    # ensure we always return a data.frame with row id
  }, error = function(e) {

    message(sprintf("Row %s failed: %s", idx, e$message))

    # return structured info instead of stopping
    hits[[idx]] = data.frame(
      error = e$message,
      stringsAsFactors = FALSE
    )
  })
}

#' Setup NCBI-Blast:
#' @title make blast database
#'
#' @param db_location location of blast database to use (created by rBLAST)
#' @param  blast_location path for NCBI blast+ (needed under Windows)
#' @param  set_blast_location Boolean to set path for NCBI blast+ (needed under Windows)
#' @param get_blast_location Boolean to retrieve and return blast+ location
#'
#'
#' @export make_blast_db
#' @import rBLAST
#' @import Biostrings
#' @import IRanges
#' @import S4Vectors
#'
make_blast_db = function(db_location,
                         blast_location = "C:/Program Files/NCBI/blast-2.17.0+/bin/",
                         set_blast_location = F,
                         get_blast_location = F){
  if (set_blast_location) {
    Sys.setenv(PATH = paste(Sys.getenv("PATH"), blast_location, sep=.Platform$path.sep))
  }
  blastdb <- rBLAST::blast(db = db_location)
  if (get_blast_location) {
    return(Sys.setenv(PATH = paste(Sys.getenv("PATH"), blast_location, sep=.Platform$path.sep)))
  }
  return(blastdb)
}
