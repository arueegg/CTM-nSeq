#' Create crRNA search window
#' @title Create crRNA search window df
#'
#' @param dataframe dataframe containing ROI information
#' @param genome BSgenome object
#' @param name_col column in dataframe to use as name
#' @param chr_col column in dataframe with end of region position
#' @param start_col column in dataframe with start of region position
#' @param end_col column in dataframe with end of region position
#' @param strand column in dataframe with strand (+/-)
#' @param window search window to apply (if set to False, set to default = 2000 bases), only used if no window column is provided in input file
#' @param sequence_extension bp by which the ROI should be extended (should be bigger than search_window, only for sequences, not relevant for search window)
#' @param save_fasta should an
#' @param save_excel excel file be saved
#' @param outputfolder output folder to save excel or fasta (will be created if not exists)
#' @param return_sequence should the sequences be returned as a Biostrings::DNAStringSet
#' @param out_name name for outputfiles
#'
#' @importFrom magrittr %>%
#' @importFrom BSgenome getBSgenome
#' @importFrom BSgenome getSeq
#' @importFrom Biostrings writeXStringSet
#' @importFrom writexl write_xlsx
#' @import BSgenome.Mmusculus.UCSC.mm39
#'
get_mm39_sequences = function(dataframe,
                              genome = getBSgenome("BSgenome.Mmusculus.UCSC.mm39"),
                              name_col = "name",
                              chr_col = "chr",
                              start_col = "start",
                              end_col = "end",
                              strand = "strand",
                              window=2000,
                              sequence_extension = 6000,
                              save_fasta = T,
                              save_excel = T,
                              outputfolder = "../ouput",
                              return_sequence = F,
                              out_name = "ROI_extended_sequences"){
  Extended_sequence = getSeq(x = genome,
                       names = dataframe[[chr_col]],
                       start = dataframe[[start_col]]-sequence_extension-window,
                       end =  dataframe[[end_col]]+sequence_extension+window,
                       strand = dataframe[[strand]])
  if(save_fasta){
    Extended_sequence@ranges@NAMES = dataframe[[name_col]]
    writeXStringSet(Extended_sequence, file=file.path(outputfolder,paste0(out_name,"_all.fasta")), format="fasta")
    for (i in 1:length(Extended_sequence)) {
      writeXStringSet(Extended_sequence[i],
                      file = file.path(outputfolder,paste0(names(Extended_sequence)[i], ".fasta")),
                      format = "fasta")
    }

  }
  if (save_excel) {
    dataframe[[out_name]] =as.character(Extended_sequence)
    write_xlsx(dataframe, file.path(outputfolder,paste0(out_name,".fasta")))
  }
  if (return_sequence) {
    return(Extended_sequence)
  }
}
