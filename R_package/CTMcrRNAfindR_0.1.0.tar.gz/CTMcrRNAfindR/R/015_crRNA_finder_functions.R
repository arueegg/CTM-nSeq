######find potential crRNAs######
#'
#'design crRNAs suitable for CTMSeq
#'
#'
#' @param sequence DNAString object
#' @param sequence_name names for sequence
#' @param strand which strand of the given DNA object should be analyzsed ("+"/"-")
#' @param PAM PAM
#' @param ps_length protospacer length (default = 20)
#' @param OH_start position after PAM where overhang starts (default = 19)
#' @param OH_end position after PAM where overhang ends (default = 23)
#' @param pGC min. GC content of overhang
#' @param search_window search window to limit crRNAs to (5' start to x) (default = 2000)
#' @importFrom dplyr filter
#' @importFrom magrittr %>%
#' @importFrom Biostrings DNAStringSet matchPattern reverseComplement subseq letterFrequency DNAString
#'
#'
find_crRNAs = function(sequence,
                       sequence_name,
                       strand,
                       search_window,
                       PAM = "TTTV",
                       ps_length = 20,
                       OH_start =19,
                       OH_end = 23,
                       pGC=0.6){
  seq = sequence
  if(strand == "-"){
    seq = reverseComplement(seq)
    }
  PAMs <- matchPattern(PAM, seq,fixed=FALSE)
  PAMdf = as.data.frame(PAMs@ranges)
  PAMdf$PAM = strsplit(toString(PAMs), split=", " )[[1]]
  PAMdf$protospacer =PAMdf$OH = PAMdf$GC_content = NA
  PAMdf = filter(PAMdf, (PAMdf$end+ps_length+10)<search_window)
  for (i in 1:nrow(PAMdf)) {
    PAMdf$protospacer[[i]] = toString(subseq(seq, start =PAMdf$end[i]+1, end =PAMdf$end[i]+ps_length ))
    PAMdf$OH[[i]] = toString(subseq(seq, start =PAMdf$end[i]+1+OH_start,  end=PAMdf$end[i]+1+OH_end))
    PAMdf$GC_content[[i]] = letterFrequency(DNAString(PAMdf$OH[[i]]),
                                            as.prob = T,  letters="CG")
    split_name = strsplit(sequence_name, split = "\\.")
    PAMdf$crRNA_name = paste(paste(split_name[[1]][1], PAMdf$start, sep = "-"),split_name[[1]][2], sep = ".")

  }
  filteredPAMdf = filter(PAMdf, PAMdf$GC_content>=pGC)
  return(filteredPAMdf)
}

######find multiple crRNAs######
#' @title find multiple crRNAs
#' @description find multipl crRNAs based on an impor df
#'
#'
#' @param crRNA_regions dataframe with genome coordinates (only works on dataframes generated
#' through filter_input & define_search_windows)
#' @param PAM PAM
#' @param ps_length protospacer length (default = 20)
#' @param OH_start position after PAM where overhang starts (default = 19)
#' @param OH_end position after PAM where overhang ends (default = 23)
#' @param pGC min. GC content of overhang (default = 0.6)
#' @param search_window search window to limit crRNAs to (5' start to x) (default = 2000) value or vector of same lenght as crRNA_regions

#' @importFrom Biostrings DNAStringSet
#' @importFrom dplyr bind_rows select
#' @importFrom magrittr %>%
#' @import BSgenome.Mmusculus.UCSC.mm39
#'
#'
find_multiple_crRNAs = function(crRNA_regions,
                                PAM = "TTTV",
                                ps_length = 20,
                                OH_start =19,
                                OH_end = 23,
                                pGC=0.6,
                                search_window = 2000){
  all_ROIs= get_mm39_sequences(crRNA_regions,
                                            genome = getBSgenome("BSgenome.Mmusculus.UCSC.mm39"),
                                            name_col = "name.crRNA",
                                            chr_col = "chr",
                                            start_col = "start",
                                            end_col = "end",
                                            strand = "strand",
                                            sequence_extension = 0,
                                            save_fasta = F,
                                            save_excel = F,
                                            outputfolder = "../ouput",
                                            return_sequence = T,
                                            out_name = "ROI_extended_sequences")
  all_ROIs@ranges@NAMES = crRNA_regions$name.crRNA

  all_crRNAs = list()
  #starttime = Sys.time()
  for (i in 1:length(all_ROIs)) {
    sw = ifelse(length(search_window) == length(all_ROIs), search_window[[i]], search_window)
    name = paste(all_ROIs@ranges@NAMES[[i]], sep = "_")
    crRNAs = find_crRNAs(sequence= all_ROIs[[i]],
                         sequence_name = name,
                         strand = "+", #since sequence already was selected based on strand! otherwise use all_ROIs@metadata$strand[[i]],,
                         PAM = PAM,
                         ps_length = ps_length,
                         OH_start =OH_start,
                         OH_end = OH_end,
                         pGC=pGC,
                         search_window = sw
    )
    all_crRNAs[[name]]=crRNAs
  }
  #endtime = Sys.time()
  #print(endtime-starttime)
  combined_df <- bind_rows(all_crRNAs)
  combined_df$name.crRNA = combined_df$crRNA_name
  combined_df = combined_df %>% select(-crRNA_name)
  combined_df$pref_name.crRNA = bind_rows(all_crRNAs, .id = "name.crRNA")$name.crRNA
  return(combined_df)
}



