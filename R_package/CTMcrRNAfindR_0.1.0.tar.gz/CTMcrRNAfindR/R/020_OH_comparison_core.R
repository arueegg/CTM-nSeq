#' @title update combos
#' @description
#' helper function to update combinations during extract_pairs_from_matrix_incremental
#' @param current_combinations ...
#' @param new_indices ...
#'
#'
update_combos <- function(current_combinations, new_indices) {
  # Repeat current combinations for each new index
  n_current <- nrow(current_combinations)
  n_new <- length(new_indices)
  # Repeat each row of current_combinations n_new times
  combinations <- current_combinations[rep(1:n_current, each = n_new), , drop = FALSE]
  # Tile new_indices to match the expanded combinations
  new_indices_repeated <- rep(new_indices, times = n_current)
  # Combine horizontally
  return(cbind(combinations, new_indices_repeated))
}


#' @title extract OH combinations
#' @description
#'  extract OH combinations with acceptable score
#'
#' @param matrix matrix with OH scores
#' @param group_sizes_rows number of elements for groups in rows
#' @param group_sizes_cols number of elements for groups in columns
#' @param target_value maximum acceptable match score (default  = 1)
#'
#' @importFrom dplyr recode

#'
extract_pairs <- function(matrix, group_sizes_rows, group_sizes_cols, target_value = 1) {

  n_groups <- length(group_sizes_rows)

  # Create group tags for rows and columns
  group_tags_row <- rep(1:n_groups, times = group_sizes_rows)
  group_tags_col <- rep(1:n_groups, times = group_sizes_cols)

  # Initialize lists to store indices
  i_list <- list()
  j_list <- list()

  combinations <- NULL

  for (g in 1:n_groups) {
    # Find indices where matrix <= target_value within group g
    # Create masks for current group
    row_mask <- matrix(group_tags_row, nrow = length(group_tags_row), ncol = length(group_tags_col))
    col_mask <- matrix(group_tags_col, nrow = length(group_tags_row), ncol = length(group_tags_col), byrow = TRUE)

    # Find indices where conditions are met
    indices_g <- which((matrix <= target_value) & (row_mask == g) & (col_mask == g), arr.ind = TRUE)

    i_indices <- indices_g[, 1]
    j_indices <- indices_g[, 2]

    # Store indices
    i_list[[g]] <- i_indices
    j_list[[g]] <- j_indices

    if (g == 1) {
      # Initialize combinations with indices for first group
      combinations <- matrix(1:length(i_indices), ncol = 1)
    } else {
      # Update combinations with new group
      combinations <- update_combos(combinations, 1:length(i_indices))

      # Create i_comb and j_comb matrices
      i_comb <- matrix(0, nrow = nrow(combinations), ncol = g)
      j_comb <- matrix(0, nrow = nrow(combinations), ncol = g)

      for (gg in 1:g) {
        i_comb[, gg] <- i_list[[gg]][combinations[, gg]]
        j_comb[, gg] <- j_list[[gg]][combinations[, gg]]
      }

      # Check which combinations are valid
      mask <- logical(nrow(combinations))

      for (idx in 1:nrow(combinations)) {
        # Extract submatrix for this combination
        sub_matrix <- matrix[i_comb[idx, ], j_comb[idx, ]]
        # Check if all elements are <= target_value
        mask[idx] <- all(sub_matrix <= target_value)
      }

      # Filter combinations
      combinations <- combinations[mask, , drop = FALSE]

      cat(sprintf('After processing group %d, valid combinations: %d\n', g, nrow(combinations)))

      valid_i <- i_comb[mask, , drop = FALSE]
      valid_j <- j_comb[mask, , drop = FALSE]
      if (nrow(combinations) == 0) {
        cat(crayon::red$bold(sprintf('\n\nSTOPPED execution at group %d, no more valid combinations\n\n', g)))
        list_return = list()
        list_return$result = NA
        return(list_return)
        break
      }
    }
  }

  # Prepare final output as array with dimensions (n_submatrices, n_blocks, 2)
  n_submatrices <- nrow(valid_i)
  result <- array(0, dim = c(n_submatrices, n_groups, 2))
  result[, , 1] <- valid_i
  result[, , 2] <- valid_j

  #use names instead of indexes for output
  names_i = setNames(rownames(matrix),1:nrow(matrix))
  names_j=  setNames(colnames(matrix),1:ncol(matrix))
  result2 <- array(0, dim = c(n_submatrices, n_groups, 2))
  result2[, , 1] <- dplyr::recode(result[, , 1], !!!names_i)
  result2[, , 2] <- dplyr::recode(result[, , 2], !!!names_j)

  row_list <- asplit(valid_i, 1)

  # combine data
  combined_matrix <- apply(result2, c(1, 2), function(x) {
    paste0("(", x[1], ",", x[2], ")")
  })

  # Convert to data frame (avoids row name issues with tibbles)
  combined_df <- as.data.frame(combined_matrix)

  #create a list with all pairs to look into in downstream analysis
  groups = unique(sub("_.*", "", rownames(matrix)))
  pairs_to_check = as.list(setNames(1:length(groups), groups))
  for (i in 1:ncol(combined_df)) {
    group = sub("^.*\\(","",sub("_.*", "", combined_df[1,i]))
    pairs_to_check[[group]] = unique(combined_df[,i])
  }

  list_return = list()
  list_return$result = result
  list_return$pairs_to_check = pairs_to_check
  list_return$named_results = result2

  return(list_return)
}

#' @title filter by OH match score
#'
#' @param crRNA_df dataframe/matrix with crRNAs
#' @param crRNA_name_col column name in crRNA_df with names for reverse crRNAs (default = "crRNA.name")
#' @param score_mat dataframe/matrix with number of matches (crRNAs.fw as colnames, crRNA.rv as colum)
#' @param crRNAmat_namescol column name in oh_mat with names for reverse crRNAs (default = "crRNA.rv")
#' @param max_matches maximum number of matches between fw OH and complement of rv OH
#'
#'
#' @description filters crRNA df based on a matrix with calculated OH matches
#'
#' @importFrom magrittr %>%
#' @importFrom dplyr filter group_by summarise
#' @importFrom stringr str_split_i
#' @importFrom tidyr pivot_longer
#'
crRNA_match_filter = function(crRNA_df,
                              crRNA_name_col = "crRNA.name",
                              score_mat,
                              crRNAmat_namescol = "crRNA.rv",
                              max_matches){
  crRNA_df$crRNA.name = crRNA_df[[crRNA_name_col]]
  score_mat$crRNA.rv = score_mat[[crRNAmat_namescol]]
  crRNA_OH_long <- score_mat %>%
    pivot_longer(
      !c(crRNA.rv),
      names_to= "crRNA.fw",
      values_to = "OH.matches"
    )
  crRNA_OH_long = as.data.frame(crRNA_OH_long)
  crRNA_OH_long_ok = crRNA_OH_long %>% filter(OH.matches<=max_matches)
  crRNA_OH_long_ok$locus.fw = stringr::str_split_i(as.character(crRNA_OH_long_ok$crRNA.fw), "_",1)
  crRNA_OH_long_ok$locus.rv = stringr::str_split_i(as.character(crRNA_OH_long_ok$crRNA.rv), "_",1)
  summary_crOHs = crRNA_OH_long_ok %>%
    group_by(crRNA.fw, locus.fw)%>%
    summarise(OKcrRNA.rv = paste(unique(crRNA.rv), collapse = ", "),
              loci_with_matches = paste(unique(locus.rv), collapse = ", "))
  test = Reduce(intersect, summary_crOHs$OKcrRNA.rv)

  crRNA_OH_long_ok =  cbind(crRNA.pair =  paste(crRNA_OH_long_ok$crRNA.fw,crRNA_OH_long_ok$crRNA.rv, sep="&"), crRNA_OH_long_ok)
  crRNA_df_filt.fw = crRNA_df %>%
    filter(crRNA.name %in% unique(crRNA_OH_long_ok$crRNA.fw))
  crRNA_df_filt.fw$crRNA.fw = crRNA_df_filt.fw$crRNA.name
  crRNA_df_filt.fw = crRNA_df_filt.fw%>%select(-c(crRNA.name))

  crRNA_df_filt.rv = crRNA_df %>%
    filter(crRNA.name %in% unique(crRNA_OH_long_ok$crRNA.rv))
  crRNA_df_filt.rv$crRNA.rv = crRNA_df_filt.rv$crRNA.name
  crRNA_df_filt.rv = crRNA_df_filt.rv%>%select(-c(crRNA.name))

  OH_filtered_crRNAS = merge(merge(crRNA_OH_long_ok, crRNA_df_filt.fw, by = "crRNA.fw"),
                             crRNA_df_filt.rv, by = "crRNA.rv",
                             suffixes = c(".fw",".rv"))
  return(OH_filtered_crRNAS)
}



#'
#' @title Check Matching overhangs
#' @description
#' can be provided with either vectors containing forward and reverse crRNA names
#' or a dataframe with respective column names
#'
#'
#' @param crRNA_dataframe dataframe with both forward and reverse crRNA
#'
#' @param crRNA_name_col naming column for crRNAs found in crRNA_dataframe
#' @param overhangs_col overhang column for crRNAs found in crRNA_dataframe
#' @param strand_col strand (+/-) column for crRNAs found in crRNA_dataframe
#'
#' @param crRNA.name.fw vector with names of forward crRNAS
#' @param overhangs.fw vector with overhangs of forward crRNAS
#' @param crRNA.name.rv vector with names of reverse crRNAS
#' @param overhangs.rv vector with overhangs of reverse crRNAS
#'
#' @param gapOpen parameters passed to pairwiseAlignment
#' @param gapExtend parameters passed to pairwiseAlignment
#'
#'@description
#'  scoring outputs for default parameters.
#'    0 of 5 -29.49643
#'    3 of 5 5.853303
#'    1 of 5 -21.61539
#'    2 of 5 -13.73434
#'    4/5 with gaps -20.07298
#'
#' @importFrom magrittr %>%
#' @importFrom dplyr mutate across everything select as_tibble
#' @importFrom tidyr replace_na
#' @importFrom pwalign pairwiseAlignment
#' @importFrom Biostrings DNAString DNAStringSet complement
#'
#' @export Overhang_comparison
#'
Overhang_comparison = function(crRNA_dataframe = NULL,
                               crRNA_name_col = "crRNA.name",
                               overhangs_col = "overhangs",
                               strand_col = "strand",
                               crRNA.name.fw =c(),
                               overhangs.fw=c(),
                               crRNA.name.rv=c(),
                               overhangs.rv=c(),
                               gapOpen = 10,
                               gapExtend = 4){

  if (is.null(crRNA_dataframe)) {
    crRNA_df <- data.frame(
      crRNA.name = c(crRNA.name.fw, crRNA.name.rv),
      overhangs  = c(overhangs.fw, overhangs.rv),
      strand     = c(rep("+", length(crRNA.name.fw)), rep("-", length(crRNA.name.rv)))
    )
  } else {
    crRNA_df <- crRNA_dataframe
  }

  # 2. Extract FW and RV data using logical indexing (cleaner than filter())
  is_fw <- which(crRNA_df[[strand_col]] == "+")
  is_rv <- which(crRNA_df[[strand_col]] == "-")

  crRNA.name.fw <- crRNA_df[[crRNA_name_col]][is_fw]
  overhangs.fw  <- crRNA_df[[overhangs_col]][is_fw]

  crRNA.name.rv <- crRNA_df[[crRNA_name_col]][is_rv]
  overhangs.rv  <- crRNA_df[[overhangs_col]][is_rv]

  if (nrow(crRNA_df) > 0) {
    max_oh_length <- max(nchar(crRNA_df[[overhangs_col]]), na.rm = TRUE)
  } else {
    max_oh_length <- 0
  }
  #create dictionary of scores and matches (max_oh_length - missmatches)
  scores = c()
  matches = c()
  for (mms in 0:max_oh_length) {
    scoring = pwalign::pairwiseAlignment(pattern = Biostrings::DNAString(paste0(c(strrep("A", max_oh_length-mms),
                                                                      strrep("G", mms)), collapse ="")),
                                         subject = Biostrings::DNAString(strrep("A", max_oh_length)),
                                         type = "global",
                                         gapOpening=gapOpen,
                                         gapExtension=gapExtend)
    #values dictionary of scores and matches (max - missmatches)
    scores = c(scores, scoring@score)
    matches = c(matches, max_oh_length-mms)
  }
  #dictionary of scores and matches (max - missmatches)
  scoresheet = data.frame(scores =scores, matches = matches)
  scoredict = stats::setNames(paste0(scoresheet$matches),scoresheet$scores)

  fw_DNA = Biostrings::DNAStringSet(overhangs.fw)

  rv_DNA_comp = Biostrings::complement(DNAStringSet(overhangs.rv))

  match_mat = data.frame(matrix(ncol = 0,
                                nrow = length(crRNA.name.rv)),
                         crRNA.rv = crRNA.name.rv)
  for (i in 1:length(fw_DNA)) {
    OHf = fw_DNA[[i]]
    crRNA.name = crRNA.name.fw[[i]]
    alignment = try(pwalign::pairwiseAlignment(pattern = rv_DNA_comp, subject = OHf, type = "global", gapOpening=gapOpen, gapExtension=gapExtend))
    match_mat[[crRNA.name]]= alignment@score
  }

  score_mat =  match_mat %>%
    select(-c(crRNA.rv)) %>%
    as_tibble() %>%
    mutate(across(everything(), ~ scoredict[as.character(.)]))%>%
    mutate(across(everything(), ~ replace_na(., "5")))%>%
    mutate(across(everything(), ~ as.numeric(.)))

  rownames(score_mat) = match_mat$crRNA.rv


  return(score_mat)
}
#' @title reorganize score df
#'
#' @param dataframe dataframe/matrix with OH scores for crRNAs
#' @param rnames row name for dataframe, has to contain separable group (gene) ids
#' @param cnames column name for dataframe, has to contain separable group (gene) ids
#' @param group_name_sep regex string to separate groups from rest in row and colum names
#' @param max_score maximum number of matches between fw OH and complement of rv OH
#' @param reshape_to01 Boolean - reshape the matrix to 0 (above max score) and 1 (below max score)
#' @description reorganizes crRNA dataframe for input in downstream functions
#'
#' @importFrom dplyr select_if
#' @importFrom magrittr %>%
#'
reorganize_mat = function(dataframe,
                          rnames,
                          cnames,
                          group_name_sep = "\\..*",
                          max_score = 0,
                          reshape_to01 = F){
  mat <- as.matrix(as.data.frame(dataframe) %>% dplyr::select_if(is.numeric))
  rownames(mat) = rnames
  colnames(mat) = cnames

  if (reshape_to01) {
    #uniformize for all < max_score to be 1 and others to be 0
    mat[mat > max_score] <- NA
    mat[mat <= max_score] <- 1
    mat[is.na(mat)] <- 0
    max_score = 1
  }


  #get values for mat names
  groups <- unique(c(sub(group_name_sep, "", rownames(mat)),
                     sub(group_name_sep, "", colnames(mat))))
  all_cols <- colnames(mat)
  all_rows <- rownames(mat)

  #get numbers for mat names
  n_groups = length(groups)

  group_sizes_rows = vapply(unique(sub(group_name_sep, "", rownames(mat))),
                            function(x) sum(sub(group_name_sep, "", rownames(mat)) == x), numeric(1))
  group_sizes_cols = vapply(unique(sub(group_name_sep, "", colnames(mat))),
                            function(x) sum(sub(group_name_sep, "", colnames(mat)) == x), numeric(1))
  return(list(mat, group_sizes_rows, group_sizes_cols, max_score))
}

