###### Blast  crRNA ######
#' @title combine blast, score and general crRNA info
#' @description
#' merges the DeepCpf1 & RNAfold scores, blast results and general crRNA information
#'
#' @param include_scores dataframe with DeepCpf1 & RNAfold scores, must contain column "name.crRNA" found in all_crRNAs and blast_summary
#' @param all_crRNAs dataframe with general information on crRNAs , must contain column "name.crRNA" found in include_scores and blast_summary
#' @param blast_summary dataframe with summary of blast results (blastnfilter_crRNAs[[1]], must contain column "name.crRNA" found in include_scores and all_crRNAs
#' @param ONT_NA_OH overhang sequence of ONT Native adapter, complement will be added 3' of linker sequence (default = "ATTGCT")
#' @param Linker_core core sequence of linker molecule (default = "GGGCGAACAATGCAGG")
#'
#' @importFrom magrittr %>%
#'
combine_data = function(include_scores,
                        all_crRNAs,
                        blast_summary,
                        ONT_NA_OH = "ATTGCT",
                        Linker_core = "GGGCGAACAATGCAGG") {
  all_cols_not_in_scores=all_crRNAs%>% select(c("protospacer", colnames(all_crRNAs)[!(colnames(all_crRNAs) %in% colnames(include_scores))]))
  f1 =  merge(include_scores, all_cols_not_in_scores,  by = "protospacer")
  f1_cols_not_in_blast=f1%>% select(c("protospacer", colnames(f1)[!(colnames(f1) %in% colnames(blast_summary))]))
  full_summary = merge(f1_cols_not_in_blast, blast_summary, by = "protospacer", all.x = T)
  full_summary$Linker_rv = as.character(Biostrings::reverseComplement(Biostrings::DNAStringSet(
    paste0(ONT_NA_OH,Linker_core,full_summary$OH))))
  return(full_summary)
}
