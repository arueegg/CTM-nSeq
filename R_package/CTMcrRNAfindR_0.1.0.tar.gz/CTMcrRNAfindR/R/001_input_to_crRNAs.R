
#'  @title Get crRNAs
#' @description
#' Takes an inputfile (xlsx or csv) with regions of interest (and a search window (bases left and right)) based on which the sequences and potential crRNAs are retrieved
#'
#' @param infile location of excel or csv file with information
#' @param columnames vector with columns to include, must contain an equivalent (by position) of the default column names: c("name", "chr", "start", "end", "strand", "window")
#' strand should be given as "+"/"-"
#' @param merged_name_cols vector with columns to merge to a single "name"column (default = c("name"))
#' @param filtercols columns to use as filters (vector, index relates to filters)
#' @param filters filter criteria to apply (vector, indes consistent with filter_cols)
#'
#' @param genome a BSgenome object generated through getBSgenome() (eg. "BSgenome.Mmusculus.UCSC.mm39")
#' @param sequence_extension bp by which the ROI should be extended (default = 6000, should be bigger than search_window, only for sequences, not relevant for search window)
#' @param search_window search window to apply (if set to False, set to default = 2000 bases), only used if no window column is provided in input file
#' @param search_buffer buffer (in bases) to add between ROI and search window (default = 100)
#' @param save_fasta should a fasta file with the extended ROI sequences be saved
#' @param save_excel should an excel file of the final dataframe be saved
#' @param sequences_out output folder to save excel or fasta (will be created if not exists)
#'
#' @param Cas.type type of Cas12a enzyme used (default "As") will be used in names of crRNAs
#' @param protospacer_length length of protospacer (default 20), will be used in names of crRNAs
#' @param PAM PAM
#' @param OH_start position after PAM where overhang starts (default = 19)
#' @param OH_end position after PAM where overhang ends (default = 23)
#' @param pGC min. GC content of overhang (default = 0.6)
#'
#' @importFrom tidyr unite pivot_longer
#' @importFrom tools file_ext
#' @importFrom magrittr %>%
#' @importFrom dplyr filter select all_of rename bind_rows select
#' @importFrom readxl read_xlsx
#' @importFrom writexl write_xlsx
#' @importFrom BSgenome.Mmusculus.UCSC.mm39 BSgenome.Mmusculus.UCSC.mm39
#' @importFrom BSgenome getBSgenome getSeq
#' @importFrom Biostrings writeXStringSet DNAStringSet
#'
#' @export get_crRNAs
#'
get_crRNAs = function(infile,
                      columnames  = c("Assoc_locus", "Chr", "start", "end", "strand", "window"),
                      merged_name_cols = c("Assoc_locus", "feature"),
                      filtercols =c("feature"),
                      filters =c("ROI"),
                      genome = getBSgenome("BSgenome.Mmusculus.UCSC.mm39"),
                      sequence_extension =6000,
                      search_window=F,
                      search_buffer=100,
                      save_fasta = T,
                      save_excel = T,
                      sequences_out,
                      Cas.type,
                      PAM = PAM,
                      protospacer_length,
                      OH_start,
                      OH_end,
                      pGC){
  if (save_fasta || save_excel) {
    if (!dir.exists(sequences_out)) dir.create(sequences_out)
  }
  ROIs_df <- filter_input(filepath = infile,
                          columnames = columnames,
                          merged_name_cols = merged_name_cols,
                          filtercols = filtercols,
                          filters =filters)
  if (!("window" %in% colnames(ROIs_df))) {
    ROIs_df$window = ifelse(search_window !=F, search_window, 2000)
  }
  ROIs_df_windows = define_search_windows(ROIs_df,
                                          name_col="name",
                                          chr_col = "chr",
                                          start_col = "start",
                                          end_col = "end",
                                          strand_col ="strand",
                                          window=ROIs_df$window,
                                          buffer=search_buffer)
  ROIs_df_windows$seq.feature = as.character(get_mm39_sequences(ROIs_df_windows,
                                                                genome =genome,
                                                                name_col = "name",
                                                                chr_col = "chr",
                                                                start_col = "start",
                                                                end_col = "end",
                                                                strand = "strand",
                                                                sequence_extension = sequence_extension,
                                                                window=ROIs_df$window,
                                                                save_fasta = save_fasta,
                                                                save_excel = F,
                                                                outputfolder = sequences_out,
                                                                return_sequence = T,
                                                                out_name = "ROI_extended_sequences"))
  ROIs_df_windows$seq.ROI = as.character(get_mm39_sequences(ROIs_df_windows,
                                                            genome = genome,
                                                            name_col = "name",
                                                            chr_col = "chr",
                                                            start_col = "start",
                                                            end_col = "end",
                                                            strand = "strand",
                                                            sequence_extension = 0,
                                                            save_fasta = F,
                                                            save_excel = F,
                                                            outputfolder = sequences_out,
                                                            return_sequence = T,
                                                            out_name = "ROI_sequences"))
  crRNA_regions = ROIs_to_crRNA_df(ROIs_df_windows)
  all_crRNAs = find_multiple_crRNAs(crRNA_regions,
                                    PAM = PAM,
                                    ps_length = protospacer_length,
                                    OH_start =OH_start,
                                    OH_end = OH_end,
                                    pGC=pGC,
                                    search_window = crRNA_regions$window)
  all_crRNAs= merge(all_crRNAs, crRNA_regions,  by.y = "name.crRNA", by.x = "pref_name.crRNA", suffixes = c(".PAM",".window"))
  if (save_excel) {
    write_xlsx(all_crRNAs, file.path(sequences_out, "all_crRNAs.xlsx") )
  }
  return(all_crRNAs)
}





